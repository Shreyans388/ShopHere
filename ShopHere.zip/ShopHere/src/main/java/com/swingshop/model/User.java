package com.swingshop.model;

public class User {
    public int id;
    public String username;
    public User(int id, String username) { this.id = id; this.username = username; }
}
