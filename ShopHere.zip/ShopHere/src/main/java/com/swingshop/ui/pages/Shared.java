package com.swingshop.ui.pages;

import com.swingshop.model.Cart;

class Shared {
    static final Cart cart = new Cart();
}
